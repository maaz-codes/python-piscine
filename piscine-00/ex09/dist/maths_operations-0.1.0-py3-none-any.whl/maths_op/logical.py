def and_op(x: int, y: int) -> str:
    return f"evaluating... {x} AND {y}"


def or_op(x: int, y: int) -> str:
    return f"evaluating... {x} OR {y}"
