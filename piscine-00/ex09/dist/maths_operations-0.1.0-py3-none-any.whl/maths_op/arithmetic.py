def add(x: int, y: int) -> str:
    return f"adding... {x} and {y}"


def substract(x: int, y: int) -> str:
    return f"substracting... {x} from {y}"


def multiply(x: int, y: int) -> str:
    return f"multiplying... {x} with {y}"


def divide(x: int, y: int) -> str:
    return f"diving... {x} by {y}"
